import HeroModern from "@/components/land/HeroModern";

export default function Page() {
  return (
    <HeroModern/>
  )
}